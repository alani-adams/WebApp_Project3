# WebApp_Project3
after cloning git reposity on web server:
1. Copy p3dbConnect.php to ../php/ folder and edit Database username
   and password if required.
2. Source sqlP3.sql from database CLI or using GUI.
