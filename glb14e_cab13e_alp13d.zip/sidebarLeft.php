<?php
echo"
<h3>TOP Winners</h3>
<table id='topList' >
<script>
top10();
</script>
</table>
<br/>
";
?>

